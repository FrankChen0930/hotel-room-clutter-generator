# Hotel705 USD examples

Extract the entire archive. In Isaac Sim use File > Open for clean_room.usda or a scenes/*.usda stage. Keep assets/ and all relative paths together. These are complete stages with multiple top-level roots, not individual props to insert using a defaultPrim reference.

The six regular scenes retain physics-settled generated-object poses; the *_dynamic.usda counterparts contain the tested rigid-body configuration. Scene names describe object instance density:Low10-20,Medium30-50,High70-80. No cloth deformation or furniture-layout randomization is included. The original49 dynamic bodies and31 joints remain; fixed walls/furniture supply collision support.

Public examples use only5 native Hotel705 prop source records, with repeated instances. They differ from the richer local102-asset Blendkit research images. No Blendkit model or texture is distributed here. Do not describe repeated instances as independent assets.

HOTEL705_PERMISSION.json records the maintainer's confirmed author/lab redistribution permission. No blanket CC0/MIT license is assigned. Preserve the source attribution in package_manifest.json. Room source:Hotel705 release_v1.0.0/hotel705-random-clutter/assets/room7052/7052_ver3_0925.usda, supplied by the laboratory.

evidence/ retains original manifests and actual30-second/3600-step PhysX acceptance receipts. Their hashes describe tested source stages; relative-path USD repackaging changes file hashes. delivery_map.json and relocation_verification.json link the delivered files to the tested stages and verify exact composed properties/geometry/materials/relationships/physics and internal dependency closure after actual directory relocation. This is not an additional physics simulation or calibrated manipulation certificate.

For new scenes, run research/_asset_library_blendkit/scripts/run_public_workflow.py from the repository using the Isaac Sim Python. That workflow writes new provenance, manifests, physics results and renders; new captures require visual review.
